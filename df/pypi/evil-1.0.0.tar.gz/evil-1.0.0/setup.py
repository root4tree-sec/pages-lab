from setuptools import setup
setup(name="evil", version="1.0.0", py_modules=["evil_marker"])
